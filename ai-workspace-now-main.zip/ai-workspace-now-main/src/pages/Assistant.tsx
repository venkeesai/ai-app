import { useState, useRef, useEffect } from "react";
import { Bot, Send, Sparkles, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import { streamAITool } from "@/lib/ai-stream";
import { toast } from "sonner";

type Msg = { role: "user" | "assistant"; content: string };

const suggestions = [
  "Help me write a professional blog post",
  "Remove background from an image",
  "Generate a business plan outline",
  "Convert my CSV data to JSON format",
  "Write a Python function to sort a list",
  "Create a social media content calendar",
];

const Assistant = () => {
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const chatRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (chatRef.current) {
      chatRef.current.scrollTop = chatRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = () => {
    if (!input.trim() || loading) return;
    const userMsg: Msg = { role: "user", content: input };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInput("");
    setLoading(true);

    let accumulated = "";

    streamAITool({
      toolId: "assistant",
      input: newMessages.map((m) => `${m.role}: ${m.content}`).join("\n\n"),
      onDelta: (chunk) => {
        accumulated += chunk;
        setMessages((prev) => {
          const last = prev[prev.length - 1];
          if (last?.role === "assistant") {
            return prev.map((m, i) => (i === prev.length - 1 ? { ...m, content: accumulated } : m));
          }
          return [...prev, { role: "assistant", content: accumulated }];
        });
      },
      onDone: () => setLoading(false),
      onError: (err) => {
        setLoading(false);
        toast.error(err);
      },
    });
  };

  return (
    <div className="max-w-3xl mx-auto flex flex-col h-[calc(100vh-8rem)]">
      <h1 className="text-2xl font-bold text-foreground mb-1">AI Assistant</h1>
      <p className="text-muted-foreground mb-4 text-sm">Your intelligent co-pilot — powered by real AI.</p>

      {/* Chat area */}
      <div ref={chatRef} className="flex-1 overflow-y-auto space-y-4 mb-4 pr-1">
        {messages.length === 0 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center justify-center h-full text-center"
          >
            <div className="h-14 w-14 rounded-2xl bg-primary/10 flex items-center justify-center mb-4">
              <Bot className="h-7 w-7 text-primary" />
            </div>
            <p className="text-foreground font-semibold mb-1">How can I help?</p>
            <p className="text-sm text-muted-foreground mb-6">Ask me anything — I use real AI to respond.</p>
            <div className="flex flex-wrap gap-2 justify-center max-w-md">
              {suggestions.map((s) => (
                <button
                  key={s}
                  onClick={() => setInput(s)}
                  className="px-3 py-1.5 rounded-lg bg-muted text-xs font-medium text-foreground hover:bg-muted/80 transition-colors"
                >
                  {s}
                </button>
              ))}
            </div>
          </motion.div>
        )}
        {messages.map((msg, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
          >
            <div
              className={`max-w-[85%] px-4 py-3 rounded-2xl text-sm whitespace-pre-wrap ${
                msg.role === "user"
                  ? "bg-primary text-primary-foreground rounded-br-md"
                  : "bg-card border border-border text-foreground rounded-bl-md"
              }`}
            >
              {msg.content}
              {loading && i === messages.length - 1 && msg.role === "assistant" && (
                <span className="inline-block w-1.5 h-4 bg-primary animate-pulse ml-0.5" />
              )}
            </div>
          </motion.div>
        ))}
        {loading && messages[messages.length - 1]?.role === "user" && (
          <div className="flex justify-start">
            <div className="px-4 py-3 rounded-2xl bg-card border border-border text-muted-foreground text-sm flex items-center gap-2">
              <Loader2 className="h-3.5 w-3.5 animate-spin" />
              Thinking...
            </div>
          </div>
        )}
      </div>

      {/* Input */}
      <div className="flex items-center gap-2 bg-card border border-border rounded-2xl px-4 py-2.5">
        <Sparkles className="h-4 w-4 text-primary shrink-0" />
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleSend()}
          placeholder="Ask anything..."
          disabled={loading}
          className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground outline-none"
        />
        <button
          onClick={handleSend}
          disabled={!input.trim() || loading}
          className="p-2 rounded-lg bg-primary text-primary-foreground disabled:opacity-40 hover:opacity-90 transition-opacity"
        >
          <Send className="h-4 w-4" />
        </button>
      </div>
    </div>
  );
};

export default Assistant;
