import { Workflow, Plus, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

const Automations = () => (
  <div className="max-w-4xl mx-auto">
    <h1 className="text-2xl font-bold text-foreground mb-2">Automations</h1>
    <p className="text-muted-foreground mb-8">Chain tools together into powerful workflows.</p>

    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card border border-border rounded-2xl p-8 text-center"
    >
      <div className="h-16 w-16 rounded-2xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
        <Workflow className="h-8 w-8 text-primary" />
      </div>
      <h2 className="text-lg font-bold text-foreground mb-2">Visual Workflow Builder</h2>
      <p className="text-sm text-muted-foreground max-w-md mx-auto mb-6">
        Drag and drop AI tools to create automated pipelines. No login needed — workflows run in your browser session.
      </p>

      <div className="flex items-center justify-center gap-3 mb-6">
        {["Upload PDF", "Summarize", "Translate", "Export"].map((step, i) => (
          <div key={step} className="flex items-center gap-3">
            <div className="px-3 py-1.5 rounded-lg bg-muted text-xs font-medium text-foreground">{step}</div>
            {i < 3 && <ArrowRight className="h-3.5 w-3.5 text-muted-foreground" />}
          </div>
        ))}
      </div>

      <button className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-brand text-primary-foreground font-semibold text-sm hover:opacity-90 transition-opacity">
        <Plus className="h-4 w-4" />
        Create Workflow
      </button>
      <p className="text-xs text-muted-foreground mt-4">Coming soon — workflows will run entirely client-side</p>
    </motion.div>
  </div>
);

export default Automations;
