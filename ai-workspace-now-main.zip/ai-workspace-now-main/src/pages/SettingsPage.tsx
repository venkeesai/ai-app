import { Settings, Trash2, Moon, Sun } from "lucide-react";
import { motion } from "framer-motion";

const SettingsPage = () => (
  <div className="max-w-2xl mx-auto">
    <h1 className="text-2xl font-bold text-foreground mb-6">Settings</h1>

    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-4"
    >
      <div className="bg-card border border-border rounded-2xl p-5">
        <h2 className="text-sm font-semibold text-foreground mb-3">Appearance</h2>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-foreground">Dark Mode</p>
            <p className="text-xs text-muted-foreground">Switch between light and dark themes</p>
          </div>
          <button
            onClick={() => document.documentElement.classList.toggle("dark")}
            className="p-2.5 rounded-lg bg-muted hover:bg-muted/80 transition-colors"
          >
            <Sun className="h-4 w-4 text-foreground dark:hidden" />
            <Moon className="h-4 w-4 text-foreground hidden dark:block" />
          </button>
        </div>
      </div>

      <div className="bg-card border border-border rounded-2xl p-5">
        <h2 className="text-sm font-semibold text-foreground mb-3">Data</h2>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-foreground">Clear Local Data</p>
            <p className="text-xs text-muted-foreground">Remove all saved outputs and history</p>
          </div>
          <button
            onClick={() => {
              localStorage.clear();
              window.location.reload();
            }}
            className="flex items-center gap-2 px-3 py-2 rounded-lg bg-destructive/10 text-destructive text-sm font-medium hover:bg-destructive/20 transition-colors"
          >
            <Trash2 className="h-3.5 w-3.5" />
            Clear
          </button>
        </div>
      </div>

      <div className="bg-card border border-border rounded-2xl p-5">
        <h2 className="text-sm font-semibold text-foreground mb-3">About</h2>
        <p className="text-sm text-muted-foreground">
          NexusAI — 100+ AI tools, zero login required. All processing happens via secure APIs.
          Your data stays in your browser.
        </p>
      </div>
    </motion.div>
  </div>
);

export default SettingsPage;
