import { FolderOpen, Info } from "lucide-react";
import { motion } from "framer-motion";

const Saved = () => (
  <div className="max-w-4xl mx-auto">
    <h1 className="text-2xl font-bold text-foreground mb-2">Saved Projects</h1>
    <p className="text-muted-foreground mb-6 text-sm">Your locally stored outputs and files.</p>

    <div className="flex items-center gap-2 p-3 rounded-lg bg-primary/5 border border-primary/10 text-xs text-primary mb-6">
      <Info className="h-4 w-4 shrink-0" />
      All data is stored locally in this browser. Nothing is sent to a server.
    </div>

    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-card border border-border rounded-2xl p-12 text-center"
    >
      <FolderOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
      <p className="text-foreground font-semibold mb-1">No saved items yet</p>
      <p className="text-sm text-muted-foreground">Results you save from any tool will appear here.</p>
    </motion.div>
  </div>
);

export default Saved;
