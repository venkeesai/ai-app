import { useNavigate } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight, Sparkles, Zap, TrendingUp } from "lucide-react";
import { categories, getTrendingTools, tools } from "@/data/tools";

const fadeUp = {
  hidden: { opacity: 0, y: 16 },
  visible: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.05, duration: 0.4 } }),
};

const Index = () => {
  const navigate = useNavigate();
  const trending = getTrendingTools();

  return (
    <div className="max-w-6xl mx-auto space-y-10">
      {/* Hero */}
      <motion.section
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-center py-8"
      >
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 text-primary text-xs font-semibold mb-5">
          <Sparkles className="h-3.5 w-3.5" />
          100+ AI Tools — No Login Required
        </div>
        <h1 className="text-4xl md:text-5xl font-extrabold text-foreground tracking-tight leading-tight">
          Your AI <span className="text-gradient">Super Workspace</span>
        </h1>
        <p className="mt-3 text-muted-foreground text-lg max-w-xl mx-auto">
          Generate, create, convert, and automate — instantly. No signup, no barriers.
        </p>

        {/* Quick actions */}
        <div className="flex flex-wrap justify-center gap-3 mt-8">
          {[
            { label: "Write Content", cat: "writing" },
            { label: "Generate Images", cat: "image" },
            { label: "Write Code", cat: "code" },
            { label: "Analyze Data", cat: "data" },
          ].map((a) => (
            <button
              key={a.cat}
              onClick={() => navigate(`/explore?category=${a.cat}`)}
              className="px-5 py-2.5 rounded-xl bg-card border border-border text-sm font-medium text-foreground hover:border-primary/30 hover:shadow-glow transition-all"
            >
              {a.label}
            </button>
          ))}
        </div>
      </motion.section>

      {/* Trending Tools */}
      <section>
        <div className="flex items-center gap-2 mb-5">
          <TrendingUp className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-bold text-foreground">Trending Tools</h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {trending.map((tool, i) => {
            const cat = categories.find((c) => c.id === tool.category);
            return (
              <motion.button
                key={tool.id}
                custom={i}
                initial="hidden"
                animate="visible"
                variants={fadeUp}
                onClick={() => navigate(`/tool/${tool.id}`)}
                className="group flex items-center gap-4 p-4 rounded-xl bg-card border border-border hover:border-primary/30 hover:shadow-glow transition-all text-left"
              >
                <div
                  className="h-10 w-10 rounded-xl flex items-center justify-center shrink-0"
                  style={{ backgroundColor: `hsl(${cat?.color || "200 50% 50%"} / 0.12)` }}
                >
                  <tool.icon
                    className="h-5 w-5"
                    style={{ color: `hsl(${cat?.color || "200 50% 50%"})` }}
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground truncate">{tool.name}</p>
                  <p className="text-xs text-muted-foreground truncate">{tool.description}</p>
                </div>
                <ArrowRight className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
              </motion.button>
            );
          })}
        </div>
      </section>

      {/* Categories */}
      <section>
        <div className="flex items-center gap-2 mb-5">
          <Zap className="h-5 w-5 text-primary" />
          <h2 className="text-lg font-bold text-foreground">Categories</h2>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
          {categories.map((cat, i) => {
            const count = tools.filter((t) => t.category === cat.id).length;
            return (
              <motion.button
                key={cat.id}
                custom={i}
                initial="hidden"
                animate="visible"
                variants={fadeUp}
                onClick={() => navigate(`/explore?category=${cat.id}`)}
                className="group p-4 rounded-xl bg-card border border-border hover:border-primary/20 hover:shadow-glow transition-all text-left"
              >
                <div
                  className="h-10 w-10 rounded-xl flex items-center justify-center mb-3"
                  style={{ backgroundColor: `hsl(${cat.color} / 0.12)` }}
                >
                  <cat.icon className="h-5 w-5" style={{ color: `hsl(${cat.color})` }} />
                </div>
                <p className="text-sm font-semibold text-foreground">{cat.name}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{count} tools</p>
              </motion.button>
            );
          })}
        </div>
      </section>

      {/* Stats */}
      <section className="grid grid-cols-3 gap-4 py-6">
        {[
          { label: "AI Tools", value: `${tools.length}+` },
          { label: "Categories", value: categories.length.toString() },
          { label: "No Signup", value: "Free" },
        ].map((s) => (
          <div key={s.label} className="text-center p-4 rounded-xl bg-card border border-border">
            <p className="text-2xl font-extrabold text-gradient">{s.value}</p>
            <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
          </div>
        ))}
      </section>
    </div>
  );
};

export default Index;
