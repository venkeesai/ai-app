import { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Search, ArrowRight, X } from "lucide-react";
import { searchTools, categories, type Tool } from "@/data/tools";
import { motion, AnimatePresence } from "framer-motion";

export function SearchOverlay({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  const results = query.length > 0 ? searchTools(query).slice(0, 8) : [];

  useEffect(() => {
    if (open) {
      setQuery("");
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [open]);

  const handleSelect = (tool: Tool) => {
    navigate(`/tool/${tool.id}`);
    onClose();
  };

  const getCategoryColor = (cat: string) => {
    return categories.find((c) => c.id === cat)?.color || "200 50% 50%";
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
          className="fixed inset-0 z-[100] flex items-start justify-center pt-[15vh] px-4"
          onClick={onClose}
        >
          <div className="fixed inset-0 bg-background/70 backdrop-blur-md" />
          <motion.div
            initial={{ opacity: 0, scale: 0.96, y: -8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: -8 }}
            transition={{ duration: 0.2 }}
            onClick={(e) => e.stopPropagation()}
            className="relative w-full max-w-xl glass-strong rounded-2xl shadow-lg overflow-hidden"
          >
            {/* Input */}
            <div className="flex items-center gap-3 px-5 h-14 border-b border-border/50">
              <Search className="h-5 w-5 text-muted-foreground shrink-0" />
              <input
                ref={inputRef}
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search 100+ AI tools..."
                className="flex-1 bg-transparent text-foreground placeholder:text-muted-foreground outline-none text-base"
              />
              <button onClick={onClose} className="p-1 rounded hover:bg-muted">
                <X className="h-4 w-4 text-muted-foreground" />
              </button>
            </div>

            {/* Results */}
            <div className="max-h-80 overflow-y-auto">
              {query.length === 0 && (
                <div className="p-5 text-center text-sm text-muted-foreground">
                  Type to search tools, categories, or describe what you need...
                </div>
              )}
              {query.length > 0 && results.length === 0 && (
                <div className="p-5 text-center text-sm text-muted-foreground">
                  No tools found for "{query}"
                </div>
              )}
              {results.map((tool, i) => (
                <button
                  key={tool.id}
                  onClick={() => handleSelect(tool)}
                  className="w-full flex items-center gap-4 px-5 py-3 hover:bg-muted/50 transition-colors text-left"
                >
                  <div
                    className="h-9 w-9 rounded-lg flex items-center justify-center shrink-0"
                    style={{ backgroundColor: `hsl(${getCategoryColor(tool.category)} / 0.12)` }}
                  >
                    <tool.icon
                      className="h-4.5 w-4.5"
                      style={{ color: `hsl(${getCategoryColor(tool.category)})` }}
                    />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-foreground truncate">{tool.name}</p>
                    <p className="text-xs text-muted-foreground truncate">{tool.description}</p>
                  </div>
                  <ArrowRight className="h-4 w-4 text-muted-foreground shrink-0" />
                </button>
              ))}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
