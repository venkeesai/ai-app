import { NavLink, useLocation } from "react-router-dom";
import {
  LayoutDashboard, Compass, Workflow, Bot, FolderOpen, Settings, Sparkles, X,
} from "lucide-react";

const navItems = [
  { to: "/", icon: LayoutDashboard, label: "Dashboard" },
  { to: "/explore", icon: Compass, label: "Explore Tools" },
  { to: "/automations", icon: Workflow, label: "Automations" },
  { to: "/assistant", icon: Bot, label: "Assistant" },
  { to: "/saved", icon: FolderOpen, label: "Saved" },
  { to: "/settings", icon: Settings, label: "Settings" },
];

export function AppSidebar({ onClose }: { onClose: () => void }) {
  const location = useLocation();

  return (
    <div className="h-full flex flex-col bg-card border-r border-border">
      {/* Logo */}
      <div className="h-14 flex items-center justify-between px-5 border-b border-border">
        <div className="flex items-center gap-2.5">
          <div className="h-8 w-8 rounded-lg bg-gradient-brand flex items-center justify-center">
            <Sparkles className="h-4 w-4 text-primary-foreground" />
          </div>
          <span className="font-bold text-lg text-foreground tracking-tight">NexusAI</span>
        </div>
        <button onClick={onClose} className="lg:hidden p-1 rounded hover:bg-muted">
          <X className="h-4 w-4 text-muted-foreground" />
        </button>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-1">
        {navItems.map((item) => {
          const active = location.pathname === item.to || (item.to !== "/" && location.pathname.startsWith(item.to));
          return (
            <NavLink
              key={item.to}
              to={item.to}
              onClick={onClose}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                active
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              }`}
            >
              <item.icon className="h-4.5 w-4.5" />
              {item.label}
            </NavLink>
          );
        })}
      </nav>

      {/* Bottom */}
      <div className="p-3 m-3 rounded-lg bg-gradient-subtle border border-border/50">
        <p className="text-xs font-semibold text-foreground mb-1">100+ AI Tools</p>
        <p className="text-xs text-muted-foreground">No login required. Use instantly.</p>
      </div>
    </div>
  );
}
