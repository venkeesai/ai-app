import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { script, duration, numScenes } = await req.json();

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    const scenesCount = numScenes || Math.max(3, Math.min(8, Math.ceil(duration / 5)));

    const systemPrompt = `You are a video scene planner. Given a script, break it into exactly ${scenesCount} visual scenes for a ${duration}-second video.

Return ONLY valid JSON (no markdown, no code fences) in this exact format:
{
  "scenes": [
    {
      "sceneNumber": 1,
      "title": "Scene title",
      "narration": "The narration text for this scene",
      "imagePrompt": "Detailed image generation prompt describing what should be shown visually. Be specific about colors, lighting, composition, style. Cinematic, high quality.",
      "durationSeconds": 5
    }
  ]
}

Rules:
- Each scene should have a vivid, detailed imagePrompt suitable for AI image generation
- Distribute the total ${duration} seconds across scenes
- narration should contain the portion of the script for that scene
- imagePrompt must NOT contain text/words to render, focus on visual elements only
- Make imagePrompts cinematic, photorealistic or stylized as appropriate`;

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: `Script:\n${script}` },
        ],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please wait and try again." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Usage limit reached. Please add credits." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const text = await response.text();
      console.error("AI video error:", response.status, text);
      return new Response(JSON.stringify({ error: "Scene generation failed." }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await response.json();
    let content = data.choices?.[0]?.message?.content || "";

    // Strip code fences if present
    content = content.replace(/```json\s*/gi, "").replace(/```\s*/gi, "").trim();

    let scenes;
    try {
      scenes = JSON.parse(content);
    } catch {
      console.error("Failed to parse scenes:", content);
      return new Response(JSON.stringify({ error: "Failed to parse scene data. Please try again." }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify(scenes), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("ai-video error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
