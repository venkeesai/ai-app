import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { prompt, toolId } = await req.json();

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY is not configured");

    // Build a better prompt based on the tool
    let enhancedPrompt = prompt;
    switch (toolId) {
      case "logo-maker":
        enhancedPrompt = `Create a professional, clean logo design on a white background: ${prompt}. The logo should be simple, memorable, and suitable for business use. No text unless specifically requested.`;
        break;
      case "icon-gen":
        enhancedPrompt = `Create a clean, minimal icon design: ${prompt}. Flat design style, suitable for app or web use. Simple shapes, bold colors, transparent or solid background.`;
        break;
      case "banner-maker":
        enhancedPrompt = `Create a professional web banner: ${prompt}. Wide format, eye-catching design with clear visual hierarchy.`;
        break;
      case "avatar-gen":
        enhancedPrompt = `Create a unique stylized avatar: ${prompt}. Suitable for a profile picture, creative and memorable.`;
        break;
      case "thumbnail-maker":
        enhancedPrompt = `Create an eye-catching YouTube thumbnail: ${prompt}. Bold colors, high contrast, attention-grabbing composition. 16:9 aspect ratio.`;
        break;
      case "meme-gen":
        enhancedPrompt = `Create a funny meme image: ${prompt}. Include appropriate text overlay in meme style.`;
        break;
      case "infographic":
        enhancedPrompt = `Create a clean, informative infographic: ${prompt}. Use icons, charts, and clear visual hierarchy to present information.`;
        break;
      case "image-gen":
      default:
        enhancedPrompt = `Generate a high-quality image: ${prompt}. Ultra high resolution, photorealistic or artistic as appropriate.`;
        break;
    }

    const response = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-2.5-flash-image",
        messages: [
          { role: "user", content: enhancedPrompt },
        ],
        modalities: ["image", "text"],
      }),
    });

    if (!response.ok) {
      if (response.status === 429) {
        return new Response(JSON.stringify({ error: "Rate limit exceeded. Please wait a moment and try again." }), {
          status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      if (response.status === 402) {
        return new Response(JSON.stringify({ error: "Usage limit reached. Please add credits to continue." }), {
          status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const text = await response.text();
      console.error("AI image error:", response.status, text);
      return new Response(JSON.stringify({ error: "Image generation failed. Please try again." }), {
        status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const data = await response.json();
    const images = data.choices?.[0]?.message?.images || [];
    const textContent = data.choices?.[0]?.message?.content || "";

    return new Response(JSON.stringify({ images, text: textContent }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("ai-image error:", e);
    return new Response(
      JSON.stringify({ error: e instanceof Error ? e.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
